# Hello APK Demo

A tiny native Android app written in Java. It shows a greeting and a button tap counter.

## Build on GitHub

1. Push this project to a GitHub repository on the `main` branch.
2. Open the repository's **Actions** tab. The `Build Android APK` workflow runs on each push to `main`; you can also start it using **Run workflow**.
3. When the run succeeds, open the run and download `hello-apk-demo-debug` under **Artifacts**.

The artifact is a debug-signed APK for testing, not a production release. GitHub keeps it for 14 days.

## Build locally

Requires JDK 17, Android SDK Platform 35, and Gradle 8.9:

```sh
gradle assembleDebug
```

APK output: `app/build/outputs/apk/debug/app-debug.apk`.
